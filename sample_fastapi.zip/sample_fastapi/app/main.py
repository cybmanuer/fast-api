from fastapi import FastAPI
from app.db.session import engine
from app.db import base
from app.models import client, course
from app.routes import client as client_routes, course as course_routes

# Create all tables
base.Base.metadata.create_all(bind=engine)

app = FastAPI(title="FastAPI Clients & Courses API")

# Include routes
app.include_router(client_routes.router)
app.include_router(course_routes.router)
