from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.client import ClientCreate, ClientOut
from app.crud import client as client_crud
from app.db.session import get_db

router = APIRouter(prefix="/clients", tags=["Clients"])

@router.post("/", response_model=ClientOut)
def add_client(client: ClientCreate, db: Session = Depends(get_db)):
    return client_crud.create_client(db, client)

@router.get("/", response_model=list[ClientOut])
def list_clients(db: Session = Depends(get_db)):
    return client_crud.get_clients(db)

@router.put("/{client_id}", response_model=ClientOut)
def edit_client(client_id: int, client: ClientCreate, db: Session = Depends(get_db)):
    return client_crud.update_client(db, client_id, client)

@router.delete("/{client_id}")
def remove_client(client_id: int, db: Session = Depends(get_db)):
    return client_crud.delete_client(db, client_id)
