#Store configuration values (e.g., database URL)

import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    PROJECT_NAME: str = "FastAPI Sample Project"
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql://postgres:priti@123@localhost:5432/fastapidb"
    )

settings = Settings()
