from sqlalchemy.orm import declarative_base

Base = declarative_base()


# Import all models so tables get created