from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.course import CourseCreate, CourseOut
from app.crud import course as course_crud
from app.db.session import get_db

router = APIRouter(prefix="/courses", tags=["Courses"])

@router.post("/", response_model=CourseOut)
def add_course(course: CourseCreate, db: Session = Depends(get_db)):
    return course_crud.create_course(db, course)

@router.get("/", response_model=list[CourseOut])
def list_courses(db: Session = Depends(get_db)):
    return course_crud.get_courses(db)

@router.put("/{course_id}", response_model=CourseOut)
def edit_course(course_id: int, course: CourseCreate, db: Session = Depends(get_db)):
    return course_crud.update_course(db, course_id, course)

@router.delete("/{course_id}")
def remove_course(course_id: int, db: Session = Depends(get_db)):
    return course_crud.delete_course(db, course_id)
